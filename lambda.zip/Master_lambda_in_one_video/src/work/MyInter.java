package work;

@FunctionalInterface
public interface MyInter {
	public abstract void sayHello();
}
