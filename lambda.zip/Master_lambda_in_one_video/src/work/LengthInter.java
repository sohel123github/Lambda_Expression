package work;
@FunctionalInterface
public interface LengthInter {
	
	int getLength (String str);
}
