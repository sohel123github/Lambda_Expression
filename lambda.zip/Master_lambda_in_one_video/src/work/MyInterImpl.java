package work;

public class MyInterImpl implements MyInter {

	@Override
	public void sayHello() {
		System.out.println("Hello, from my MyInterImpl..");		
	}
	
	
}
